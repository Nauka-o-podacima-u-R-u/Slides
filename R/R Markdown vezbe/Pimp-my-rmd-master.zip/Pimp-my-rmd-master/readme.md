Pimp my RMD
===================

This repository provides a few tips I need to remember to customize the appearance of my [R Markdown](https://rmarkdown.rstudio.com) documents.  

You can have a look to these tips here: https://holtzy.github.io/Pimp-my-rmd/
